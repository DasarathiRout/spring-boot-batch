package com.dasarathi.spring.ex12.job;

import com.dasarathi.spring.ex12.model.Transaction;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.item.ItemProcessor;

public class TransactionProcessor implements ItemProcessor<Transaction, Transaction> {

    private static final Logger log = LoggerFactory.getLogger(TransactionProcessor.class);

    @Override
    public Transaction process(final Transaction currentTransaction) throws Exception {
        final String reference = currentTransaction.getReference().toUpperCase();
        final String amount = Long.parseLong(currentTransaction.getAmount()) > 0L ?
                "DR " + currentTransaction.getAmount() :
                "CR " + currentTransaction.getAmount();
        final Transaction transformedTransaction = new Transaction();
        transformedTransaction.setReference(reference);
        transformedTransaction.setAmount(amount);
        log.info(currentTransaction + " => " + transformedTransaction);
        return transformedTransaction;
    }

}