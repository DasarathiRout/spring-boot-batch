package com.dasarathi.spring.ex12.model;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import java.io.Serializable;

@Entity
@Table(name = "TRANSACTION_LOG")
public class Transaction implements Serializable {
    private static final long serialVersionUID = 19876L;

    @Id
    private int sid;
    private String amount;
    private String reference;
    private String timestamp;

    //SNO,TRX ID,AMOUNT,TIMES
    public Transaction() {
    }

    public int getSid() {
        return sid;
    }

    public void setSid(int sid) {
        this.sid = sid;
    }

    public String getAmount() {
        return amount;
    }

    public void setAmount(String amount) {
        this.amount = amount;
    }

    public String getReference() {
        return reference;
    }

    public void setReference(String reference) {
        this.reference = reference;
    }

    public String getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(String timestamp) {
        this.timestamp = timestamp;
    }

    @Override
    public String toString() {
        return String.format("Transaction( %s , %s , %s , %s );", sid, amount, reference, timestamp);
    }
}