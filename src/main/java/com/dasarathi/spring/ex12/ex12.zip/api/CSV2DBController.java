package com.dasarathi.spring.ex12.api;

import com.dasarathi.spring.ex12.jpa.TransactionRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping(value = "/csv2db", produces = {MediaType.APPLICATION_JSON_VALUE})
public class CSV2DBController {
    @Autowired
    private TransactionRepository repository;

    @GetMapping(value = "/process")
    public ResponseEntity processTransactions() {
        return ResponseEntity.ok("STARTED");
    }

    @GetMapping("/transactions/{id}")
    ResponseEntity searchTransactions(@PathVariable Integer id) {
        return ResponseEntity.ok(repository.findById(id).get());
    }

}