package com.dasarathi.spring.ex12;

import com.dasarathi.spring.api.vo.CustomerService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobParameter;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.JobParametersBuilder;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.HashMap;
import java.util.Map;

@Component
public class RunEx12 {
    private static final Logger LOG = LoggerFactory.getLogger(RunEx12.class);
    @Autowired
    JobLauncher jobLauncher;

    @Autowired
    Job runJob;

    public void invoke() {
        Map<String, String> ex12KV = new HashMap<>();
        ex12KV.put("API", "EX-12");
        ex12KV.put("INPUT_FILE", "/data/INPUT.CUSTOMER.TRNX.CSV");
        Map<String, JobParameter> jobParameterMap = new HashMap<>();

        for (Map.Entry<String, String> entry : ex12KV.entrySet()) {
            jobParameterMap.put(entry.getKey(), new JobParameter(entry.getValue(), true));
        }

        jobParameterMap.put("APPLICATION", new JobParameter("SPRING.BOOT.BATCH", false));
        JobParameters jobParameters = new JobParametersBuilder(new JobParameters(jobParameterMap)).toJobParameters();

        try {
            jobLauncher.run(runJob, jobParameters);
        } catch (Exception e) {
            LOG.error("OOPS, Running Example-12 Failed.");
        } finally {
            ex12KV.clear();
            jobParameterMap.clear();
        }
    }

}
