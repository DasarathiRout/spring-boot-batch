package com.dasarathi.spring.ex12.config;

import com.dasarathi.spring.ex12.job.TransactionProcessor;
import com.dasarathi.spring.ex12.jpa.TransactionRepository;
import com.dasarathi.spring.ex12.model.Transaction;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepScope;
import org.springframework.batch.integration.async.AsyncItemProcessor;
import org.springframework.batch.integration.async.AsyncItemWriter;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.batch.item.database.JdbcBatchItemWriter;
import org.springframework.batch.item.database.builder.JdbcBatchItemWriterBuilder;
import org.springframework.batch.item.file.FlatFileItemReader;
import org.springframework.batch.item.file.builder.FlatFileItemReaderBuilder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.Resource;
import org.springframework.core.task.SimpleAsyncTaskExecutor;

import javax.sql.DataSource;

@Configuration
@EnableBatchProcessing
public class CSV2DBConfiguration {

    private final String[] COLUMNS = {
            "SNO", "TRXID", "AMOUNT", "TIMES"
    };
    @Autowired
    public JobBuilderFactory jobBuilderFactory;
    @Autowired
    public StepBuilderFactory stepBuilderFactory;
    @Autowired
    private TransactionRepository repository;

    @Bean
    @StepScope
    public FlatFileItemReader<Transaction> transactionFileReader(
            @Value("#{jobParameters['INPUT_FILE']}") Resource resource) {
        return new FlatFileItemReaderBuilder<Transaction>()
                .saveState(false)
                .resource(resource)
                .delimited()
                .names(COLUMNS)
                .fieldSetMapper(fieldSet -> {
                    Transaction transaction = new Transaction();
                    transaction.setSid(Integer.parseInt(fieldSet.readString(COLUMNS[0])));
                    transaction.setReference(fieldSet.readString(COLUMNS[1]));
                    transaction.setAmount(fieldSet.readString(COLUMNS[2]));
                    transaction.setTimestamp(fieldSet.readString(COLUMNS[3]));
                    return transaction;
                })
                .build();
    }

    @Bean
    @StepScope
    public JdbcBatchItemWriter<Transaction> writer(DataSource dataSource) {
        return new JdbcBatchItemWriterBuilder<Transaction>()
                .dataSource(dataSource)
                .beanMapped()
                .sql("INSERT INTO TRANSACTION ( SID, REFERENCE, AMOUNT, TIMESTAMP) VALUES (:sid :reference, :amount, :timestamp)")
                .build();
    }

    @Bean
    public AsyncItemProcessor<Transaction, Transaction> asyncItemProcessor() {
        AsyncItemProcessor<Transaction, Transaction> processor = new AsyncItemProcessor<>();
        processor.setDelegate(processor());
        processor.setTaskExecutor(new SimpleAsyncTaskExecutor());
        return processor;
    }

    @Bean
    public AsyncItemWriter<Transaction> asyncItemWriter() {
        AsyncItemWriter<Transaction> writer = new AsyncItemWriter<>();
        writer.setDelegate(writer(null));
        return writer;
    }

    @Bean
    public TransactionProcessor processor() {
        return new TransactionProcessor();
    }

    @Bean
    public Job asyncJob() {
        return this.jobBuilderFactory.get("Async-Job-CSV2DB")
                .start(stepOneAsync())
                .build();
    }


    @Bean
    public Step stepOneAsync() {
        return this.stepBuilderFactory.get("Step-One-Async")
                .<Transaction, Transaction>chunk(100)
                .reader(transactionFileReader(null))
                .processor((ItemProcessor) asyncItemProcessor())
                .writer(asyncItemWriter())
                .build();
    }

}