package com.dasarathi.spring.ex12.jpa;

import com.dasarathi.spring.ex12.model.Transaction;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface TransactionRepository extends JpaRepository<Transaction, Integer> {
}